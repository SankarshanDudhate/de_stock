import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:destock/loginscreen1.dart';
class dashboard extends StatefulWidget {
  dashboard({Key key, this.title}) : super(key: key);
  final String title;
  @override
  _dashboardState createState() => _dashboardState();
}
class _dashboardState extends State<dashboard> {

  Widget _options() {
    return Container(
        decoration: BoxDecoration(
          color: Colors.white,
        ),
        padding: EdgeInsets.symmetric(horizontal: 10),
        child: Row(
          children: <Widget>[
            Container(
              padding: EdgeInsets.only(left: 0, top: 10, bottom: 10),
              child: Image.asset("assets/images/destocklogo.png"),
              width:30,
            ),
            SizedBox(width: 5,),
            Text('De- Stock',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700))
          ],
        ),
      );

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SingleChildScrollView(
            child:Container(

              height: MediaQuery.of(context).size.height,
              decoration: BoxDecoration(
                color: Color(0xfff3f3f3),
              ),

              child: Column(
                children: <Widget>[
                  header(
                    headline1:'Hello Ajay',
                    headline2:'Welcome to your dashboard !',
                    headline3:'Complete you profile for better reach!',
                    image: "assets/images/USER PROFILE PIC.png",
                  ),
                  SizedBox(height: 10,),
                  product_view_card(
                    products:'0',
                    pro_text:'Active\nProducts',
                    views:'0',
                    view_text: "Total\nviews",
                  ),
                  options(
                    title: "My profile",
                    image: "assets/images/destocklogo.png",
                  ),

                ],
              ),
            )
        )
    );
  }

}

class header extends StatelessWidget {
  final String headline1;
  final String headline2;
  final String headline3;
  final String image;
  const header({Key key, this.headline1, this.headline2,this.headline3, this.image})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: double.infinity,
        height: 200,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(40),
              bottomRight: Radius.circular(40)),
          color: Color(0xffD84764),

        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Text(headline1,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),),
                Text(headline2,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.white),),
                Text(headline3,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: Colors.black),),
              ],
            ),
            Image.asset(image, height: 50),
          ],
        )
    );
  }
}

class product_view_card extends StatelessWidget {
  final String products;
  final String views;
  final String pro_text;
  final String view_text;
  final String image;
  const product_view_card({Key key, this.products, this.views,this.pro_text, this.view_text,this.image})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: 250,
        height: 100,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          color: Color(0xffffffff),

        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(products,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),),
                Text(pro_text,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black),),
              ],
            ),
            VerticalDivider(color: Colors.black38,),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(views,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),),
                Text(view_text,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: Colors.black),),
              ],
            ),
          ],
        )
    );
  }
}



class options extends StatelessWidget {
  final String title;
  final String image;
  const options({Key key, this.title, this.image})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        padding: EdgeInsets.symmetric(horizontal: 20),
        width: 150,
        height: 50,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10),),
          color: Color(0xfffffff),

        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
          Image.asset(image, height: 15,),
            Text(title,
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.white),),
          ],
        )
    );
  }
}

  /*class dashboard extends StatelessWidget {

  GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
  return Scaffold(
  key: _scaffoldKey,
  body: Container(
  height: 160.0,
  child: Stack(
  children: <Widget>[
  Container(
  color: Colors.red,
  width: MediaQuery.of(context).size.width,
  height: 120.0,

  child: Center(
  child: Text(
  "Home",
  style: TextStyle(color: Colors.white, fontSize: 18.0),
  ),
  ),
  ),
  Positioned(
  top: 100.0,
  left: 0.0,
  right: 0.0,
  child: Container(
  padding: EdgeInsets.symmetric(horizontal: 20.0),
  child: DecoratedBox(
  decoration: BoxDecoration(
  borderRadius: BorderRadius.circular(1.0),
  border: Border.all(
  color: Colors.grey.withOpacity(0.5), width: 1.0),
  color: Colors.white),
  child: Row(
  children: [
  IconButton(
  icon: Icon(
  Icons.menu,
  color: Colors.red,
  ),
  onPressed: () {
  print("your menu action here");
  _scaffoldKey.currentState.openDrawer();
  },
  ),
  Expanded(
  child: TextField(
  decoration: InputDecoration(
  hintText: "Search",
  ),
  ),
  ),
  IconButton(
  icon: Icon(
  Icons.search,
  color: Colors.red,
  ),
  onPressed: () {
  print("your menu action here");
  },
  ),
  IconButton(
  icon: Icon(
  Icons.notifications,
  color: Colors.red,
  ),
  onPressed: () {
  print("your menu action here");
  },
  ),
  ],
  ),
  ),
  ),
  )
  ],
  ),
  ),
  );
  }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Dashboard'),
      ),
    );
  }
*/
